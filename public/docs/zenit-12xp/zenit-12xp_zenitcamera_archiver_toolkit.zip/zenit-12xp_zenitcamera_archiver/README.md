# Zenit-12xp / Zenit-12sd Russian Manual Archiver

This package is a ready-to-run archiver for the three Zenitcamera source pages only:

1. `https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp-repair.html`
2. `https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp-catalog.html`
3. `https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp.html`

It downloads the original HTML, extracts the original Russian page content into Markdown, downloads all locally referenced images and linked high-resolution image files where available, rewrites image references to local paths, and creates a ZIP archive.

## Why this is a toolkit rather than a completed scrape

The ChatGPT execution environment used to build this package could not resolve `zenitcamera.com`, and the available web fetcher reported redirect-loop errors for the Zenitcamera pages. Because of that, the actual manuals and images were **not** extracted here. No text has been reconstructed from search snippets or mirrors.

Run the script below on a normal internet-connected machine to build the complete archive directly from the Zenitcamera pages.

## Requirements

Python 3.10 or newer.

Install dependencies:

```bash
python3 -m pip install requests beautifulsoup4 lxml markdownify pillow
```

`pillow` is optional but useful for recording image dimensions in the manifest.

## Run

From this folder:

```bash
python3 scripts/archive_zenit_12xp.py
```

The completed archive will be written to:

```text
archive_output/zenit-12xp_zenit-12sd_original-russian_zenitcamera_archive.zip
```

The main extracted Markdown will be:

```text
archive_output/zenit-12xp_zenit-12sd_original-russian_zenitcamera.md
```

## Output structure

```text
archive_output/
├── README_ARCHIVE.md
├── source_manifest.csv
├── original_url_index.md
├── zenit-12xp_zenit-12sd_original-russian_zenitcamera.md
├── raw_html/
│   ├── zenit-12xp-repair.html
│   ├── zenit-12xp-catalog.html
│   └── zenit-12xp-user-manual.html
└── images/
    ├── repair/
    ├── catalog/
    └── user-manual/
```

## Notes

- The script does not use mirrors, translated English manuals, forum posts, auction pages, or PDFs from other sites.
- It keeps text in the original language and does not translate it.
- It records the original source URL for every downloaded HTML page and asset.
- If an inline image is wrapped in a link to a larger `.tif`, `.tiff`, `.jpg`, `.png`, or `.gif`, the script downloads the linked larger file as the preferred high-resolution asset.
