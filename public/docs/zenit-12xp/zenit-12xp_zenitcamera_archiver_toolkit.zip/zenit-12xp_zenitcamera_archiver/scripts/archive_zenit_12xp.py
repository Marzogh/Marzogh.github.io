#!/usr/bin/env python3
"""
Archive the original Russian Zenit-12xp / Zenit-12sd pages from zenitcamera.com.

Source-limited by design. Uses only:
- https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp-repair.html
- https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp-catalog.html
- https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp.html

Outputs raw HTML, local images/high-res linked assets, Markdown, manifest, and ZIP.
"""
from __future__ import annotations

import csv
import hashlib
import mimetypes
import re
import shutil
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin, urlparse, unquote

import requests
from bs4 import BeautifulSoup, Tag
from markdownify import markdownify as md

try:
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None

BASE_DIR = Path(__file__).resolve().parents[1]
OUT_DIR = BASE_DIR / "archive_output"
RAW_DIR = OUT_DIR / "raw_html"
IMG_DIR = OUT_DIR / "images"

SOURCES = [
    {
        "key": "repair",
        "title": "ЗЕНИТ-12xp, ЗЕНИТ-12сд -- Инструкция по ремонту",
        "url": "https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp-repair.html",
        "raw_name": "zenit-12xp-repair.html",
        "image_dir": "repair",
    },
    {
        "key": "catalog",
        "title": "ЗЕНИТ-12сд / ZENIT-12xp -- Каталог сборок и деталей",
        "url": "https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp-catalog.html",
        "raw_name": "zenit-12xp-catalog.html",
        "image_dir": "catalog",
    },
    {
        "key": "user-manual",
        "title": "ЗЕНИТ-12xp -- Руководство",
        "url": "https://www.zenitcamera.com/mans/zenit-12xp/zenit-12xp.html",
        "raw_name": "zenit-12xp-user-manual.html",
        "image_dir": "user-manual",
    },
]

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".tif", ".tiff", ".bmp", ".webp"}
HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; Zenit12xpArchiver/1.0; archival personal-use scraper)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
}

@dataclass
class ManifestRow:
    kind: str
    source_page_key: str
    source_page_url: str
    original_url: str
    local_path: str
    mime_type: str = ""
    bytes: int = 0
    sha256: str = ""
    width: str = ""
    height: str = ""
    note: str = ""


def ensure_dirs() -> None:
    OUT_DIR.mkdir(exist_ok=True)
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    for src in SOURCES:
        (IMG_DIR / src["image_dir"]).mkdir(parents=True, exist_ok=True)


def safe_stem(text: str, fallback: str = "asset") -> str:
    text = unquote(text)
    text = re.sub(r"[?#].*$", "", text)
    text = Path(text).name or fallback
    stem = Path(text).stem or fallback
    stem = re.sub(r"[^A-Za-z0-9._-]+", "-", stem).strip("-._")
    return stem or fallback


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def detect_dims(path: Path) -> tuple[str, str]:
    if Image is None:
        return "", ""
    try:
        with Image.open(path) as im:
            w, h = im.size
        return str(w), str(h)
    except Exception:
        return "", ""


def fetch(session: requests.Session, url: str, *, timeout: int = 40) -> requests.Response:
    r = session.get(url, timeout=timeout, allow_redirects=True)
    r.raise_for_status()
    return r


def decode_html(resp: requests.Response) -> str:
    # Zenit pages may be UTF-8 or legacy Cyrillic. requests apparent_encoding is usually reliable here.
    enc = resp.encoding or resp.apparent_encoding or "utf-8"
    try:
        return resp.content.decode(enc, errors="replace")
    except Exception:
        return resp.content.decode("utf-8", errors="replace")


def choose_content(soup: BeautifulSoup) -> Tag:
    # Old static pages are simple. Remove navigation/script noise, then use body.
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    body = soup.body or soup
    return body


def is_asset_url(url: str) -> bool:
    path = urlparse(url).path.lower()
    return Path(path).suffix in IMAGE_EXTS


def preferred_image_url(img: Tag, page_url: str) -> tuple[str, str]:
    """Prefer linked high-res asset around an image; otherwise use img src."""
    src = img.get("src") or ""
    inline_url = urljoin(page_url, src)
    parent = img.parent
    if isinstance(parent, Tag) and parent.name == "a" and parent.get("href"):
        candidate = urljoin(page_url, parent.get("href"))
        if is_asset_url(candidate):
            return candidate, "linked full-size image preferred over inline image"
    return inline_url, "inline image"


def extension_from_response(url: str, resp: requests.Response) -> str:
    ext = Path(urlparse(url).path).suffix.lower()
    if ext:
        return ext
    content_type = resp.headers.get("content-type", "").split(";")[0].strip().lower()
    guessed = mimetypes.guess_extension(content_type) or ""
    return guessed or ".bin"


def download_asset(
    session: requests.Session,
    asset_url: str,
    source: dict,
    seq: int,
    note: str,
    manifest: list[ManifestRow],
    url_to_local: dict[str, str],
) -> str:
    if asset_url in url_to_local:
        return url_to_local[asset_url]
    resp = fetch(session, asset_url, timeout=60)
    ext = extension_from_response(asset_url, resp)
    stem = safe_stem(urlparse(asset_url).path, f"{source['key']}-{seq:03d}")
    local_name = f"{source['key']}_asset-{seq:03d}_{stem}{ext if not stem.lower().endswith(ext) else ''}"
    local_path = IMG_DIR / source["image_dir"] / local_name
    local_path.write_bytes(resp.content)
    rel = local_path.relative_to(OUT_DIR).as_posix()
    url_to_local[asset_url] = rel
    width, height = detect_dims(local_path)
    manifest.append(
        ManifestRow(
            kind="image_or_linked_asset",
            source_page_key=source["key"],
            source_page_url=source["url"],
            original_url=asset_url,
            local_path=rel,
            mime_type=resp.headers.get("content-type", "").split(";")[0],
            bytes=len(resp.content),
            sha256=sha256_file(local_path),
            width=width,
            height=height,
            note=note,
        )
    )
    return rel


def localize_images(
    soup: BeautifulSoup,
    source: dict,
    session: requests.Session,
    manifest: list[ManifestRow],
    url_to_local: dict[str, str],
) -> None:
    seq = 1
    page_url = source["url"]
    for img in soup.find_all("img"):
        asset_url, note = preferred_image_url(img, page_url)
        if not asset_url:
            continue
        try:
            rel = download_asset(session, asset_url, source, seq, note, manifest, url_to_local)
            img["src"] = rel
            img["data-original-url"] = asset_url
            if img.parent and isinstance(img.parent, Tag) and img.parent.name == "a":
                img.parent["href"] = rel
        except Exception as e:
            img["data-download-error"] = str(e)
        seq += 1

    # Also download direct links to image/TIFF assets that may not wrap an <img>.
    for a in soup.find_all("a", href=True):
        href = urljoin(page_url, a["href"])
        if is_asset_url(href):
            try:
                rel = download_asset(session, href, source, seq, "direct linked image/TIFF asset", manifest, url_to_local)
                a["href"] = rel
            except Exception as e:
                a["data-download-error"] = str(e)
            seq += 1


def clean_markdown(markdown: str) -> str:
    markdown = markdown.replace("\r\n", "\n").replace("\r", "\n")
    markdown = re.sub(r"\n{3,}", "\n\n", markdown)
    markdown = re.sub(r"[ \t]+\n", "\n", markdown)
    return markdown.strip() + "\n"


def write_manifest(rows: Iterable[ManifestRow]) -> None:
    path = OUT_DIR / "source_manifest.csv"
    fields = [
        "kind", "source_page_key", "source_page_url", "original_url", "local_path",
        "mime_type", "bytes", "sha256", "width", "height", "note",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row.__dict__)


def write_index_and_readme() -> None:
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    index = ["# Original URL index", "", f"Archive generated: `{now}`", ""]
    for src in SOURCES:
        index.append(f"- **{src['title']}**: {src['url']}")
    (OUT_DIR / "original_url_index.md").write_text("\n".join(index) + "\n", encoding="utf-8")

    readme = f"""# Zenit-12xp / Zenit-12sd original Russian Zenitcamera archive

Generated: `{now}`

This archive was generated from the three Zenitcamera pages listed in `original_url_index.md`.

Contents:

- `zenit-12xp_zenit-12sd_original-russian_zenitcamera.md`: extracted Markdown in the original page language.
- `raw_html/`: downloaded source HTML pages.
- `images/`: downloaded inline and linked image/TIFF assets, renamed for stable local use.
- `source_manifest.csv`: source URL, local filename, MIME type, byte size, SHA-256 checksum, image dimensions where available, and notes.

No translation has been applied.
"""
    (OUT_DIR / "README_ARCHIVE.md").write_text(readme, encoding="utf-8")


def zip_output() -> Path:
    zip_path = OUT_DIR / "zenit-12xp_zenit-12sd_original-russian_zenitcamera_archive.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in OUT_DIR.rglob("*"):
            if path == zip_path or path.is_dir():
                continue
            zf.write(path, path.relative_to(OUT_DIR))
    return zip_path


def main() -> int:
    ensure_dirs()
    manifest: list[ManifestRow] = []
    combined_md: list[str] = []
    url_to_local: dict[str, str] = {}

    with requests.Session() as session:
        session.headers.update(HEADERS)
        for source in SOURCES:
            print(f"Fetching {source['url']}")
            resp = fetch(session, source["url"])
            html = decode_html(resp)
            raw_path = RAW_DIR / source["raw_name"]
            raw_path.write_text(html, encoding="utf-8")
            manifest.append(
                ManifestRow(
                    kind="html_page",
                    source_page_key=source["key"],
                    source_page_url=source["url"],
                    original_url=source["url"],
                    local_path=raw_path.relative_to(OUT_DIR).as_posix(),
                    mime_type=resp.headers.get("content-type", "").split(";")[0],
                    bytes=len(resp.content),
                    sha256=sha256_file(raw_path),
                    note="raw HTML saved as UTF-8 decoded text",
                )
            )

            soup = BeautifulSoup(html, "lxml")
            localize_images(soup, source, session, manifest, url_to_local)
            content = choose_content(soup)
            markdown = clean_markdown(md(str(content), heading_style="ATX"))
            combined_md.append(f"# {source['title']}\n\nИсточник: {source['url']}\n\n{markdown}")

    md_path = OUT_DIR / "zenit-12xp_zenit-12sd_original-russian_zenitcamera.md"
    md_path.write_text("\n\n---\n\n".join(combined_md), encoding="utf-8")
    write_manifest(manifest)
    write_index_and_readme()
    zip_path = zip_output()
    print(f"Wrote {zip_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
